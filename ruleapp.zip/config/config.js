const config = {
	// API接口，必须是HTTPS开头
	"api": "http://192.168.50.101",
	// 应用
	"app": "QQE5puRz",
	// 版本号，禁止私自修改，后果自负
	"version": "1.0.0",
	// 首页分享处描述
	"description": "rule",
}

// 导出配置
export default config;