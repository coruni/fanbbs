import adapter from '../adapters/index'


export default (config) => {
  return adapter(config)
}
