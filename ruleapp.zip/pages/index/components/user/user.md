这是page:user用的组件 用于swiper-item的内容填充
